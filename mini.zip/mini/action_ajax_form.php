<?php

$result = ['success' => false];

if (isset($_POST["name"]) && isset($_POST["email"]) && isset($_POST["message"]) ) {

	// Формируем массив для JSON ответа

    // Переводим массив в JSON
    if (mail("ip.ua97@gmail.com", "Заказ с сайта", "Имя:".decoder($_POST["name"].". E-mail: ".decoder($_POST["email"]).' Сообщение '.decoder($_POST["message"]) ,"From: admin@ipoliarush.pp.ua \r\n"))
    $result = ['success' => true];

    header('Content-Type: application/json');
    echo json_encode($result);
}

function decoder($mess) {
  return urldecode(urldecode(htmlspecialchars($mess)));
}

?>
